/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.employee;

/**
 *
 * @author Lenovo
 */
public class wanderer extends Harbinger6th {      
    public float Komisi_3099;     
    public float TotalPenjualan_3099;     
    public float Totalgaji_3099; 
    String nama_3099;
     
     public wanderer(){ 
         
    } 
     
    public float TotalGaji_3099(){ 
        Totalgaji_3099 = gajiPokok_3099 + (Komisi_3099 * TotalPenjualan_3099);         
        return Totalgaji_3099; 
    } 

    public void TampilData_3099(){ 
        System.out.println("Komisi Karyawan"); 
        Tampil_3099(); 
        System.out.println("Total Gaji: " + Totalgaji_3099); 
    } 
} 
