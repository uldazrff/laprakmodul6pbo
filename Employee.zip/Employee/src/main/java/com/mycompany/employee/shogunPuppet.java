/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.employee;

/**
 *
 * @author Lenovo
 */
public class shogunPuppet extends Harbinger6th {     
    public float Komisi_3099;     
    public float TotalHslProyek_3099;     
    public double Totalgaji_3099; 
     
    public shogunPuppet(){ 
         
    }              
    public double TotalGaji_3099(){ 
        Totalgaji_3099 = (gajiPokok_3099 *5/100) - gajiPokok_3099 + (Komisi_3099 * TotalHslProyek_3099);         
        return Totalgaji_3099; 
    } 
        public void TampilData_3099(){ 
        System.out.println("Perancang Proyek"); 
        Tampil_3099(); 
        System.out.println("Total Gaji: " + Totalgaji_3099); 
    } 
} 

