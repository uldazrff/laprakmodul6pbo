/* 
*	Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license 
*	Click 
nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${pack agePath}/${mainClassName}.java to edit this template 
 */ 
 
package com.mycompany.employee; 
 
import java.io.BufferedReader; import java.io.InputStreamReader; 
 
/** 
 * 
*	@author lenovo 
 */ 
public class ProjectPlanner { 
 
    public static void main(String[] args) {        
        scaramouche ulda_3099 = new scaramouche();         
        wanderer zana_3099 = new wanderer();         
        shogunPuppet rozzaul_3099 = new shogunPuppet(); 
         
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));  
      
        try{ 
            System.out.println("Data Pegawai");             
            System.out.print("Nama              : ");             
            ulda_3099.nama_3099 = br.readLine(); 
            System.out.print("NIP               : ");             
            ulda_3099.nip_3099 = br.readLine();             
            System.out.print("Gaji Pokok        : "); 
            ulda_3099.gajiPokok_3099 = Float.valueOf(br.readLine());             
            System.out.println("");             
            ulda_3099.TampilData_3099(); 
            System.out.println(""); 
            System.out.println(""); 
             
            System.out.print("Nama              : ");             
            zana_3099.nama_3099 = br.readLine();             
            System.out.print("NIP               : ");             
            zana_3099.nip_3099 = br.readLine();             
            System.out.print("GajiPokok         : "); 
            zana_3099.gajiPokok_3099 = Float.parseFloat(br.readLine());             
            System.out.print("Komisi            : "); 
            zana_3099.Komisi_3099 = Float.parseFloat(br.readLine());             
            System.out.print("Total Penjualan   : "); 
            zana_3099.TotalPenjualan_3099 = Float.parseFloat(br.readLine());             
            zana_3099.TotalGaji_3099();             
            System.out.println("");             
            zana_3099.TampilData_3099(); 
            System.out.println("");             
            System.out.println(""); 
             
            System.out.print("Nama              : ");             
            rozzaul_3099.nama_3099 = br.readLine();             
            System.out.print("NIP               : ");             
            rozzaul_3099.nip_3099 = br.readLine(); 
            System.out.print("Gaji Pokok        : "); 
            rozzaul_3099.gajiPokok_3099 = Float.parseFloat(br.readLine());             
            System.out.print("Komisi            : "); 
            rozzaul_3099.Komisi_3099 = Float.parseFloat(br.readLine());             
            System.out.print("Total Hasil Proyek: "); 
            rozzaul_3099.TotalHslProyek_3099 = Float.parseFloat(br.readLine());             
            rozzaul_3099.TotalGaji_3099();             
            System.out.println("");             
            rozzaul_3099.TampilData_3099();            
        } 
         
        catch(Exception ex){ 
            System.out.println(ex); 
        } 
    } 
} 
